//
//  NTESAppDefine.h
//  NERtcSample-GroupVideoCall-iOS-Objective-C
//
//  Created by Wenchao Ding on 2020/8/20.
//  Copyright © 2020 Wenchao Ding. All rights reserved.
//

#ifndef NTESAppDefine_h
#define NTESAppDefine_h

#define kAppKey @"6acf024e190215b685905444b6e57dd7"

#endif /* NTESAppDefine_h */
